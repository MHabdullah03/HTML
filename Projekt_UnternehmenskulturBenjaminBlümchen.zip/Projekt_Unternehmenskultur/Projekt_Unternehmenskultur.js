document.addEventListener("DOMContentLoaded", function () {
    const ang = document.querySelector(".ang");
    const ver = document.querySelector(".ver");
    const tex = document.querySelector(".tex");

    if (!ang || !ver || !tex) {
        console.error("Elements not found! Check class names in HTML.");
        return;
    }

    let time = 0;

    function animate() {
        time += 0.01;

        const width = window.innerWidth;

        let xOffset = Math.sin(time) * (width * 0.01);
        let rotation = Math.sin(time) * (width * 0.001);

        ang.style.transform = `translate(${xOffset}px, 0px) rotate(${rotation}deg)`;
        tex.style.transform = `translate(${xOffset}px, 0px) rotate(${rotation}deg)`;
        ver.style.transform = `translate(0px, 0px) rotate(${rotation}deg)`;

        requestAnimationFrame(animate);
    }

    animate();

    window.addEventListener("resize", function () {
        time = 0;
    });

    // Alle aufklappbaren Inhalte beim Laden verstecken
    document.querySelectorAll(".content").forEach(content => {
        content.style.display = "none";
    });

    // Event Listener für Titel hinzufügen
    document.querySelectorAll(".title").forEach(title => {
        title.addEventListener("click", function () {
            let content = this.nextElementSibling;
            if (content.style.display === "none" || content.style.display === "") {
                content.style.display = "block";
            } else {
                content.style.display = "none";
            }
        });
    });
});

// Funktion zum Öffnen und Schließen des Menüs
function toggleMenu() {
    var menu = document.getElementById("navbar");
    menu.classList.toggle("menu-open");
}

// Funktion zum sanften Hochscrollen
function scrollToTop() {
    window.scrollTo({ top: 0, behavior: "smooth" });
}

// Button anzeigen/verstecken beim Scrollen
window.addEventListener("scroll", function () {
    let button = document.getElementById("backToTop");
    if (window.scrollY > 200) {
        button.style.display = "block";
    } else {
        button.style.display = "none";
    }

    const menuIcon = document.querySelector(".menu-icon");
    const scrollPosition = window.scrollY;
    let result = 50 + (window.innerWidth * 0.5);

    if (scrollPosition > result) {
        menuIcon.classList.add("scrolled");
    } else {
        menuIcon.classList.remove("scrolled");
    }
});

// Initiales Setup beim Laden der Seite
window.addEventListener("load", function () {
    const menuIcon = document.querySelector(".menu-icon");
    const scrollPosition = window.scrollY;
    let result = 50 + (window.innerWidth * 0.5);

    if (scrollPosition > result) {
        menuIcon.classList.add("scrolled");
    } else {
        menuIcon.classList.remove("scrolled");
    }
});
